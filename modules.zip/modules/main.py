'''
import empty
empty.file2.fun()
'''
from empty import file2
file2.fun()
