print "this is f3"
def fun():
	print "this is fun in f3"