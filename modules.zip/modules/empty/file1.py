print "this is file1"
a=100
def fun():
	print "this is fun in file1"

def main():
	# statements specific to this file 
	pass

if __name__ == "__main__":
	main()